export interface Person {
    id: number;
    name: string;
    gender?: string;
    //custom datatype 
  }
  
  
  export const Persons: Person[] = [
    { id: 1, name: 'Aishwarya', gender: 'Female'},
    { id: 2, name: 'Hetsi', gender: 'Female' },
    { id: 3, name: 'Dhruv', gender: 'Male' },
    { id: 4, name: 'Kavya',gender: 'Female'}
  ];
  